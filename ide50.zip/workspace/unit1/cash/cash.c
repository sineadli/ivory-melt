// Takes a value in dollars and converts it to the least amount of coins necessary to compile it
// Sinead Li, 9/26
#include <stdio.h>
#include <cs50.h>
#include <math.h>
int main()
{
    float cho;
    int coin;
    coin = 0;
// The input must be a postive float
    do
    {
        cho = get_float("Change owed: ");
    }
    while (cho < 0);
// Convert dollars into cents and round if necessary
    cho = cho * 100;
    cho = round(cho);
// Subtract value of each type of coin and add quantity until unable (in descending order)
// Quarters
    while (cho >= 25)
    {
        coin = coin + 1;
        cho = cho - 25;
    }
// Dimes
    while (cho >= 10)
    {
        coin = coin + 1;
        cho = cho - 10;
    }
// Nickels
    while (cho >= 5)
    {
        coin = coin + 1;
        cho = cho - 5;
    }
// Pennies
    while ( cho >= 1)
    {
        coin = coin + 1;
        cho = cho - 1;
    }
// Print out
    printf("%d\n", coin);
}