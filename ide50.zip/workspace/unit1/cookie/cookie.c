// ----
///# # \
//\ # #/
// ----
// ----
#include <stdio.h>
#include <cs50.h>
int main()
{
    int numc, num, typec;
    do
    {
        numc = get_int("Number of cookies to bake (1, 6, or 12): ");
    }
    while (numc != 1&&numc !=6&&numc !=12);
    for (num = 1; num <= numc; num = num + 1)
    {
        printf(" ---- \n/    \\\n\\    /\n ---- \n");
    }
    do
    {
        typec = get_int("If you want sprinkles, type in 0, if chocolate chip, type in 1, if peanut butter, type in 2: ");
    }
    while (typec != 0&&typec !=1&&typec !=2);
    if (typec == 0)
    {
        for (num = 1; num <= numc; num = num + 1)
        {
           printf(" ---- \n/\' \' \\\n\\ \" \'/\n ---- \n");
        }
    }
    if (typec == 1)
    {
        for (num = 1; num <= numc; num = num + 1)
        {
           printf(" ----\n/o o \\\n\\ o o/\n ---- \n");
        }
    }
    if (typec == 2)
    {
       for (num = 1; num <= numc; num = num + 1)
        {
           printf(" ----\n/# # \\\n\\ # #/\n ---- \n");
        }
    }
}