// Convert fahrenheit into celsius.
// Sinead Li, 9/26
#include <stdio.h>
#include <cs50.h>
int main()
{
    float c, f;
    c = get_float("C: ");
    f = ((c * 9) / 5) + 32;
    printf("D: %.1f\n", f);
}