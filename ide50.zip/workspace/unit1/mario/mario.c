// Given a height, a mario-esque staircase made of #s will be generated.
// Sinead Li, 9/26
#include <stdio.h>
#include <cs50.h>
int main()
{
    int maxh, hash, space, lv;
// The input must be an integer between 0 and 23, exclusive.
    do
    {
        maxh = get_int("Height: ");
    }
    while (maxh < 0 || maxh > 23);
// On each level...
    for (lv = 1; lv <= maxh; lv = lv + 1)
    {
// Generate spaces, its quantity descending throughout the levels.
        for (space = 0; space <= maxh - lv - 1; space = space + 1)
        {
            printf(" ");
        }
// Generate hashtages, its quantity growing throughout the levels.
        for (hash = 2; hash <= lv + 1; hash = hash + 1)
        {
            printf("#");
        }
        printf("#\n");
    }
}