#include <stdio.h>
#include <cs50.h>
int main()
{
    int num;
    for( num = 1; num < 11; num = num + 1 ){
        printf("%d\n", num);
    }
    return 0;
}