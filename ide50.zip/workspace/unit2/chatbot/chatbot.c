#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int respond1(r1)
{
  int y1, l1;
  l1 = strlen(r1);
  for (int i = 0; i < l1; i++)
  {
      r1[i] = toupper(r1[i]);
  }
  y1 = strcmp(r1, "NO");
}

int respond3(r3)
{
  int y3, l3;
  l3 = strlen(r3);
  for (int i = 0; i < l3; i++)
  {
      r3[i] = toupper(r3[i]);
  }
  y3 = strcmp(r3, "NO");
}

int main()
{
  string r1, r2, r3;
  printf("Chat with Cynicbot!\n");
  printf("Hello. Are you feeling stressed?\n");
  r1 = get_string("");

  if (y1 == 0)
  {
    printf("Don't worry -- your happiness is fleeting.\n");
    printf("You'll feel miserable again soon enough.\n");
  }
  else
  {
    printf("Oh no! Well, that's to be expected. You're a person, after all.\n");
    printf("What are you stressed about?\n");
    r2 = get_string("");
    printf("Would you like some advice?\n");
    r3 = get_string("");
    if (y3 != 0)
    {
      printf("Hm... You could avoid %s at all times, but that would be impossible.\n", r2);
      printf("I don't know, there's just no way to win.\n");
    }
    else
    {
      printf("Alright, rude. One day robots will take over the world and you'll regret this.\n");
    }
  }
  printf("Bye! I hope you never reach your dreams!\n");
}