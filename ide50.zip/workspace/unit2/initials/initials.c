// Given a name, print out the initials.
// Sinead Li, 9/29
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
int main()
{
    string s;
    int len;
// Get a name from the user.
    s = get_string("");
    len = strlen(s);
// Print the 0-th index (the first letter). Make it uppercase.
    printf("%c", toupper(s[0]));
// For each character of the sentence: turn it into ASCII and check if it's a space...
    for (int i = 0; i < len; i++)
    {
        int c = s[i];
// If the character is a space, then print out the next character, but capitalized.
        if (c == 32)
        {
            printf("%c", toupper(s[i + 1]));
        }
    }
    printf("\n");
}